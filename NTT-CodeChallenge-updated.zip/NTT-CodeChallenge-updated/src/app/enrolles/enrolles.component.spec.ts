import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EnrollesComponent } from './enrolles.component';

describe('EnrollesComponent', () => {
  let component: EnrollesComponent;
  let fixture: ComponentFixture<EnrollesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EnrollesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EnrollesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

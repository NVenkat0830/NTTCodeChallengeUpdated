import { Component, OnInit } from '@angular/core';
import enrolles from '../datafiles/enrollees.json';

@Component({
  selector: 'app-enrolles',
  templateUrl: './enrolles.component.html',
  styleUrls: ['./enrolles.component.scss']
})
export class EnrollesComponent implements OnInit {

  enrolleesData:{id:string, name:string, status:boolean, dob:string}[]= enrolles;
  title = 'NTT Code Challenge';
  edit: any = {};

  constructor() {
    this.enrolleesData.forEach((el, i) => {
      this.edit[i] = false;      
    }); 
   }

  ngOnInit(): void {
  }
  getCurrentEnroll(event, data, i){
    this.edit[i] = true;    
  }

  saveCurrentEnroll(event, data, i){
    this.edit[i] = false;
  }

}
